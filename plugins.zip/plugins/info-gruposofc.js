let media = './media/menus/Menuvid3.mp4'
let handler = async (m, { conn, command }) => {
let fkontak = { "key": { "participants":"0@s.whatsapp.net", "remoteJid": "status@broadcast", "fromMe": false, "id": "Halo" }, "message": { "contactMessage": { "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD` }}, "participant": "0@s.whatsapp.net" }
let str = `💕 𝘽𝙄𝙀𝙉𝙑𝙀𝙉𝙄𝘿𝙊 𝘼 𝙇𝙊𝙎 𝙂𝙍𝙐𝙋𝙊𝙎 𝙊𝙁𝙄𝘾𝙄𝘼𝙇𝙀𝙎
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
𓃠 *Versión de ${gt}*
➥ ${vs}
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
✅ 𝙂𝙍𝙐𝙋𝙊𝙎 𝙊𝙁𝙄𝘾𝙄𝘼𝙇𝙀𝙎
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
✨https://chat.whatsapp.com/HMfsWgkMmdKHIlzPe6aKUK
✨https://chat.whatsapp.com/GkeE0AU0wFcAwhR55s1aIZ
✨https://chat.whatsapp.com/KcJsQr4jiGlKS3PhLdFe9k`
await conn.sendFile(m.chat, media, 'gata.mp4', str, fkontak)}

handler.command = /^linkgc|grupos|gruposSodicaBot|SodicaBotgrupos|gruposdeSodicaBot|groupofc|gruposgb|grupogb|groupgb$/i
handler.exp = 33

export default handler
handler.register = true